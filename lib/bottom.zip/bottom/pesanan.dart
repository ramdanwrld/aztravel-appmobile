import 'package:flutter/cupertino.dart';

class pesanan extends StatefulWidget {
  const pesanan({Key? key}) : super(key: key);

  @override
  State<pesanan> createState() => _pesananState();
}

class _pesananState extends State<pesanan> {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Halaman Lihat Pesanan'));
  }
}
