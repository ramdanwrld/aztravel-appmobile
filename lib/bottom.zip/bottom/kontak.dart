import 'package:flutter/cupertino.dart';

class kontak extends StatefulWidget {
  const kontak({Key? key}) : super(key: key);

  @override
  State<kontak> createState() => _kontakState();
}

class _kontakState extends State<kontak> {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('Halaman kontak'));
  }
}
