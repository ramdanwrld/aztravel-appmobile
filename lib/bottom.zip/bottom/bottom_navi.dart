import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/bottom/beranda.dart';
import 'package:flutter_application_1/bottom/kontak.dart';
import 'package:flutter_application_1/bottom/pesanan.dart';
import 'package:flutter_application_1/bottom/akun.dart';

class BottomNavi extends StatefulWidget {
  const BottomNavi({Key? key}) : super(key: key);

  @override
  State<BottomNavi> createState() => _BottomNaviState();
}

class _BottomNaviState extends State<BottomNavi> {
  int currentIndex = 0;
  final List<Widget> body = [
    beranda(),
    kontak(),
    pesanan(),
    akun(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: body[currentIndex],
        bottomNavigationBar: BottomNavigationBar(
          onTap: ontap,
          currentIndex: currentIndex,
          items: [
            BottomNavigationBarItem(
              icon: Icon(
                Icons.home,
                color: Colors.black,
              ),
              label: 'Beranda',
              activeIcon: Icon(Icons.home_outlined, color: Colors.red),
            ),
            BottomNavigationBarItem(
                icon: Icon(
                  Icons.contact_phone_sharp,
                  color: Colors.black,
                ),
                label: 'Kontak Travel',
                activeIcon:
                    Icon(Icons.contact_phone_outlined, color: Colors.red)),
            BottomNavigationBarItem(
              icon: Icon(
                Icons.shopping_bag,
                color: Colors.black,
              ),
              label: 'Lihat Pesanan',
              activeIcon: Icon(Icons.shopping_bag_outlined, color: Colors.red),
            ),
            BottomNavigationBarItem(
                icon: Icon(
                  Icons.account_box,
                  color: Colors.black,
                ),
                label: 'Akun',
                activeIcon: Icon(Icons.account_box_outlined, color: Colors.red))
          ],
        ));
  }

  void ontap(int index) {
    setState(() {
      currentIndex = index;
    });
  }
}
